package com.patxq.opencloud;

import com.patxq.opencloud.registry.ModBlocks;
import com.patxq.opencloud.registry.ModItems;
import net.fabricmc.api.ModInitializer;

public class OpenCloud implements ModInitializer {

    public static final String MOD_ID = "opencloud";
    @Override
    public void onInitialize() {
        ModItems.registerItems();
        ModBlocks.registerBlocks();

    }
}
