package com.patxq.opencloud.registry;

import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.Block;
import net.minecraft.block.Material;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class ModBlocks {

    public static final Block IPOD_PLAYER = new Block(FabricBlockSettings.of(Material.METAL).strength(4.0f));

    public static void registerBlocks() {
        Registry.register(Registry.BLOCK, new Identifier("opencloud", "ipod_player"), IPOD_PLAYER);
    }
    }
