package com.patxq.opencloud.registry;

import com.patxq.opencloud.OpenCloud;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.BlockItem;
import net.minecraft.item.FoodComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class ModItems   {

    //an instance of our new item
    public static final Item IPOD = new Item(new FabricItemSettings().group(ItemGroup.REDSTONE));
    public static final Item SIPPYCUP = new Item(new FabricItemSettings().group(ItemGroup.FOOD).food(new FoodComponent.Builder().hunger(1).saturationModifier(6f).build()));

    // Blocks
    public static final BlockItem IPOD_PLAYER = new BlockItem(ModBlocks.IPOD_PLAYER, new Item.Settings().group(ItemGroup.REDSTONE));


    public static void registerItems() {
        Registry.register(Registry.ITEM, new Identifier(OpenCloud.MOD_ID, "ipod"), IPOD);
        Registry.register(Registry.ITEM, new Identifier(OpenCloud.MOD_ID, "sippycup"), SIPPYCUP);
        Registry.register(Registry.ITEM, new Identifier(OpenCloud.MOD_ID, "ipod_player"), IPOD_PLAYER);

    }
}
